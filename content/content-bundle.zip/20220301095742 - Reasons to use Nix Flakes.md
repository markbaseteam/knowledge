---
id: 202203Tu095742
title: 20220301095742 - Reasons to use Nix Flakes
creation date: 2022-03-01 09:57
modification date: Tuesday 1st March 2022 09:57:42
note type:  Permanent Note
tags: development nix flakes reasons
---

# 20220301095742 - Reasons to use Nix Flakes
---
## Note
#### Reasons to use Nix flakes
-   Flakes adds project templates to Nix
-   Flakes define a standard way to say "this is a program you can run"
-   Flakes consolidate development environments into project configuration
-   Flakes can pull in dependencies from outside git repos trivially
-   Flakes can work with people that don't use flakes too
-   Flakes supports using private git repos
-   Flakes let you define system configuration alongside your application code
-   Flakes let you embed the git hash of your configurations repository into machines you deploy


---
### Previous Notes
- [20220228083802 - Nix](20220228083802%20-%20Nix.md)

---
### Forward Notes
- [20220301092528 - Installing Nix Flakes](20220301092528%20-%20Installing%20Nix%20Flakes.md)

---
### External Links
- [EX01]:
- [EX02]:
