---
id: 202204Tu132200 - Ocaml operator rationale
title: 20220419132200
creation date: 2022-04-19 13:22
modification date: Tuesday 19th April 2022 13:22:00
note type:  Permanent Note
tags: ocaml applicative operator monad
---

# 20220419132200 - Ocaml operator rationale
---
## Note

This extension is intended to provide a convenient syntax for working with monads and applicatives.

An applicative should provide a module implementing the following interface:
```ocaml
module type Applicative_syntax = sig 
  type 'a t 
  val ( let+ ) : 'a t -> ('a -> 'b) -> 'b t 
  val ( and+ ): 'a t -> 'b t -> ('a * 'b) t 
end
```

where (`let+`) is bound to the map operation and (`and+`) is bound to the monoidal product operation.

A monad should provide a module implementing the following interface:

```ocaml
module type Monad_syntax = sig 
  include Applicative_syntax 
  val ( let* ) : 'a t -> ('a -> 'b t) -> 'b t 
  val ( and* ): 'a t -> 'b t -> ('a * 'b) t 
end
```

where (`let*`) is bound to the bind operation, and (`and*`) is also bound to the monoidal product operation.


---
### Previous Notes

- [20220228094703 - OCaml](20220228094703%20-%20OCaml.md):

---
### Forward Notes
- [20220419122339 - Tezos core operators for error monad](20220419122339%20-%20Tezos%20core%20operators%20for%20error%20monad.md):

---
### External Links
- [Rationale](https://ocaml.org/manual/bindingops.html#ss:letops-rationale)
