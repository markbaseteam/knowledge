---
id: 202202Mo125610
title: 20220228125610 - Nix Flakes - An Introduction
creation date: 2022-02-28 12:56
modification date: Monday 28th February 2022 12:56:10
note type: Literature Note
tags: development nix flakes introduction
---

# 20220228125610 - Nix Flakes - An Introduction
---
## Note
Nix flakes are a new feature of the Nix package manager. 

#### Reasons to use Nix flakes
-   Flakes adds project templates to Nix
-   Flakes define a standard way to say "this is a program you can run"
-   Flakes consolidate development environments into project configuration
-   Flakes can pull in dependencies from outside git repos trivially
-   Flakes can work with people that don't use flakes too
-   Flakes supports using private git repos
-   Flakes let you define system configuration alongside your application code
-   Flakes let you embed the git hash of your configurations repository into machines you deploy

#### Installing Nix flakes

Flakes are only available in nix unstable and have to be enabled explicitly.

##### NixOS

In NixOS this can be achieved with the following options in `configuration.nix`.

###### System-wide installation

```nix
{ pkgs, ... }: {
  nix = {
    package = pkgs.nixUnstable; # or versioned attributes like nix_2_4
    extraOptions = ''
 experimental-features = nix-command flakes
 '';
   };
}
```

###### Installation as an extra command

Add command `nixFlakes` that serves as a flakes-enabled alias to the `nix` command.

```nix
{ pkgs, ... }: {
  environment.systemPackages = [
    (pkgs.writeShellScriptBin "nixFlakes" ''
 exec ${pkgs.nixFlakes}/bin/nix --experimental-features "nix-command flakes" "$@"
 '')
  ];
}
```

##### Non-NixOS

On non-nixos systems, install `nixFlakes` in your environment:
```bash
$ nix-env -iA nixpkgs.nixFlakes
```

Edit either ```~/.config/nix/nix.conf``` or ```/etc/nix/nix.conf``` and add:

```nix
experimental-features = nix-command flakes
```

This is needed to expose the Nix 2.0 CLI and flakes support that are hidden behind feature-flags.

Finally, if the Nix installation is in multi-user mode, don’t forget to restart the nix-daemon.

There is no official installer yet, but you can use the [nix-unstable-installer](https://github.com/numtide/nix-unstable-installer#systems):

#### Flake Schema

The flake.nix file is a Nix file but that has special restrictions (more on that later).

It has 3 top-level attributes:

-   `description` is a string describing the flake.
-   `inputs` is an attribute set of all the dependencies of the flake. The schema is described below.
-   `outputs` is a function of one argument that takes an attribute set of all the realized inputs, and outputs another attribute set which schema is described below.

##### Input schema

This is not a complete schema but should be enough to get you started:
```nix
{
  inputs = {
    # github example, also supported gitlab:
    nixpkgs.url = "github:Mic92/nixpkgs/master";
    # git urls
    git-example.url = "git+https://git.somehost.tld/user/path";
    # local directories (for absolute paths you can omit 'path:')
    directory-example.url = "path:/path/to/repo";
    # Use this for non-flakes
    bar.url = "github:foo/bar/branch";
    bar.flake = false;
    # Overwrite inputs in a flake
    # This is useful to use the same nixpkgs version in both flakes
    sops-nix.url = "github:Mic92/sops-nix";
    sops-nix.inputs.nixpkgs.follows = "nixpkgs";
    # Pin flakes to a specific revision
    nix-doom-emacs.url = "github:vlaci/nix-doom-emacs?rev=238b18d7b2c8239f676358634bfb32693d3706f3";
    nix-doom-emacs.flake = false;
    # To use a subdirectory of a repo, pass dir=
    nixpkgs.url = "github:foo/bar?dir=shu";
  }
}
```
Also see [the nix flake manual](https://nixos.org/manual/nix/stable/command-ref/new-cli/nix3-flake.html#flake-references).

##### Output schema
This is described in the nix package manager src/nix/flake.cc in CmdFlakeCheck.

Where:
- **system** is something like "x86_64-linux", "aarch64-linux", "i686-linux", "x86_64-darwin"
- **attr** is an attribute name like "hello"
- **flake** is a flake name like "nixpkgs".
- **store-path** is a /nix/store.. path
```nix
{ self, ... }@inputs:
{
  # Executed by `nix flake check`
  checks."<system>"."<name>" = derivation;
  # Executed by `nix build .#<name>`
  packages."<system>"."<name>" = derivation;
  # Executed by `nix build .`
  defaultPackage."<system>" = derivation;
  # Executed by `nix run .#<name>`
  apps."<system>"."<name>" = {
    type = "app";
    program = "<store-path>";
  };
  # Executed by `nix run . -- <args?>`
  defaultApp."<system>" = { type = "app"; program = "..."; };
  
  # Used for nixpkgs packages, also accessible via `nix build .#<name>`
  legacyPackages."<system>"."<name>" = derivation;
  # Default overlay, consumed by other flakes
  overlay = final: prev: { };
  # Same idea as overlay but a list or attrset of them.
  overlays = {};
  # Default module, consumed by other flakes
  nixosModule = { config }: { options = {}; config = {}; };
  # Same idea as nixosModule but a list or attrset of them.
  nixosModules = {};
  # Used with `nixos-rebuild --flake .#<hostname>`
  # nixosConfigurations."<hostname>".config.system.build.toplevel must be a derivation
  nixosConfigurations."<hostname>" = {};
  # Used by `nix develop`
  devShell."<system>" = derivation;
  # Used by `nix develop .#<name>`
  devShells."<system>"."<name>" = derivation;
  # Hydra build jobs
  hydraJobs."<attr>"."<system>" = derivation;
  # Used by `nix flake init -t <flake>`
  defaultTemplate = {
    path = "<store-path>";
    description = "template description goes here?";
  };
  # Used by `nix flake init -t <flake>#<name>`
  templates."<name>" = { path = "<store-path>"; description = ""; };
}
```
#### Using flakes project from a legacy Nix

There is a [flake-compat](https://github.com/edolstra/flake-compat) library you can use to shim legacy `default.nix` and `shell.nix` files. It will download the inputs of the flake, pass them to the flake’s `outputs` function and return an attribute set containing `defaultNix` and `shellNix` attributes. The attributes will contain the output attribute set with an extra `default` attribute pointing to current platform’s `defaultPackage` (resp. `devShell` for `shellNix`).

Place the following into `default.nix` (for `shell.nix`, replace `defaultNix` with `shellNix`) to use the shim:
```nix
(import (
  fetchTarball {
    url = "https://github.com/edolstra/flake-compat/archive/12c64ca55c1014cdc1b16ed5a804aa8576601ff2.tar.gz";
    sha256 = "0jm6nzb83wa6ai17ly9fzpqc40wg1viib8klq8lby54agpl213w5"; }
) {
  src =  ./.;
}).defaultNix

You can also use the lockfile to make updating the hashes easier using `nix flake lock --update-input flake-compat`. Add the following to your `flake.nix`:

  inputs.flake-compat = {
    url = "github:edolstra/flake-compat";
    flake = false;
  };

and add `flake-compat` to the arguments of `outputs` attribute. Then you will be able to use `default.nix` like the following:

(import (
  let
    lock = builtins.fromJSON (builtins.readFile ./flake.lock);
  in fetchTarball {
    url = "https://github.com/edolstra/flake-compat/archive/${lock.nodes.flake-compat.locked.rev}.tar.gz";
    sha256 = lock.nodes.flake-compat.locked.narHash; }
) {
  src =  ./.;
}).defaultNix
```

#### Making your evaluations pure

Nix flakes run in pure evaluation mode, which is underdocumented. Some tips for now:

-   fetchurl and fetchtar [require](https://github.com/NixOS/nix/blob/36c4d6f59247826dde32ad2e6b5a9471a9a1c911/src/libexpr/primops/fetchTree.cc#L201) a sha256 argument to be considered pure.
-   builtins.currentSystem is non-hermetic and impure. This can usually be avoided by passing the system (i.e., x86_64-linux) explicitly to derivations requiring it.

#### The nix flakes command

The `nix flake` subcommand is described in [command reference page of the unstable manual](https://nixos.org/manual/nix/unstable/command-ref/new-cli/nix3-flake.html) and here in the [Nix command/flake](https://nixos.wiki/wiki/Nix_command/flake "Nix command/flake") article.

#### Using nix flakes with NixOS

nixos-rebuild switch will read its configuration from `/etc/nixos/flake.nix` if it is present.

A basic nixos flake.nix could look like this:
```nix
{
  outputs = { self, nixpkgs }: {
    # replace 'joes-desktop' with your hostname here.
    nixosConfigurations.joes-desktop = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      modules = [ ./configuration.nix ];
    };
  };
}
```

If you want to pass on the flake inputs to external configuration files, you can use the `specialArgs` attribute:
```nix
{
  inputs.nixpkgs.url = github:NixOS/nixpkgs;
  inputs.home-manager.url = github:nix-community/home-manager;
  
  outputs = { self, nixpkgs, ... }@attrs: {
    nixosConfigurations.fnord = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = attrs;
      modules = [ ./configuration.nix ];
    };
  };
}
```

Then, you can access the flake inputs from the file `configuration.nix` like this:
```nix
{ config, lib, nixpkgs, home-manager, ... }: {
  # do something with home-manager here, for instance:
  imports = [ home-manager.nixosModule ];
  ...
}
```

nixos-rebuild also allows to specify different flake using the `--flake` flag (# is optional):
```bash
$ sudo nixos-rebuild switch --flake '.#'
```

By default nixos-rebuild will use the currents system hostname to lookup the right nixos configuration in `nixosConfigurations`. You can also override this by using appending it to the flake parameter:

```bash
$ sudo nixos-rebuild switch --flake '/etc/nixos#joes-desktop'
```

To switch a remote configuration, use:
```bash
$ nixos-rebuild --flake .#mymachine --target-host mymachine-hostname --build-host localhost switch
```

**Warning:** Remote building seems to be broken at the moment, which is why the build host is set to “localhost”.

#### Super fast nix-shell

One of the nix feature of the Flake edition is that Nix evaluations are cached.

Let’s say that your project has a `shell.nix` file that looks like this:
```nix
{ pkgs ? import <nixpkgs> { } }:
with pkgs;
mkShell {
  buildInputs = [
    nixpkgs-fmt
  ];

  shellHook = ''
 # ...
 '';
}
```

Running nix-shell can be a bit slow and take 1-3 seconds.

Now create a `flake.nix` file in the same repository:
```nix
{
  description = "my project description";

  inputs.flake-utils.url = "github:numtide/flake-utils";

  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem
      (system:
        let pkgs = nixpkgs.legacyPackages.${system}; in
        {
          devShell = import ./shell.nix { inherit pkgs; };
        }
      );
}
```

Run ```git add flake.nix``` so that Nix recognizes it.

And finally, run `nix develop`. This is what replaces the old nix-shell invocation.

Exit and run again, this command should now be super fast.

```ad-warning
**Warning:** TODO: there is an alternative version where the defaultPackage is a pkgs.buildEnv that contains all the dependencies. And then nix shell is used to open the environment.
```

##### Direnv integration

Assuming that the flake defines a `devShell` output attribute and that you are using direnv. Here is how to replace the old use nix stdlib function with the faster flake version:
```nix
use_flake() {
  watch_file flake.nix
  watch_file flake.lock
  eval "$(nix print-dev-env --profile "$(direnv_layout_dir)/flake-profile")"
}
```

Copy this in `~/.config/direnv/lib/use_flake.sh` or in `~/.config/direnv/direnvrc` or directly in your project specific `.envrc`.

With this in place, you can now replace the use nix invocation in the `.envrc` file with `use flake`:
```nix
# .envrc
use flake
```

The nice thing about this approach is that evaluation is cached.

###### Optimize the reloads

Nix Flakes has a Nix evaluation caching mechanism. Is it possible to expose that somehow to automatically trigger direnv reloads?

With the previous solution, direnv would only reload if the flake.nix or flake.lock files have changed. This is not completely precise as the flake.nix file might import other files in the repository.

###### Setting the bash prompt like nix-shell

A [new experimental feature of flakes](https://github.com/NixOS/nix/pull/4189) allow to setup a bash-prompt per flake:
```nix
{
  description = "...";
  nixConfig.bash-prompt = "\[nix-develop\]$ ";
  ...
}
```

Otherwise it's also possible to set the `nix develop` bash prompt system wide using the [nix.conf option bash-prompt](https://nixos.org/manual/nix/unstable/command-ref/conf-file.html). (On nixos I think it is set in `nix.extraOptions`)

#### Pushing Flakes to Cachix

[https://docs.cachix.org/pushing#flakes](https://docs.cachix.org/pushing#flakes)

#### Build specific attributes in a flake repository

When in the repository top-level, run `nix build .#<attr>`. It will look in the `legacyPackages` and `packages` output attributes for the corresponding derivation.

Eg, in nixpkgs:

```shell
$ nix build .#hello
```
#### Importing packages from multiple channels

You can import packages from different channels by creating an overlay on the _pkgs_ attribute :
```nix
let
  overlay-unstable = final: prev: {
    unstable = nixpkgs-unstable.legacyPackages.${prev.system}; # considering nixpkgs-unstable is an input registered before.
  };
in nixpkgs.overlays = [ overlay-unstable ]; # we assign the overlay created before to the overlays of nixpkgs.
```

should make a package accessible through
```nix
pkgs.unstable.package
```

For example, a NixOS config flake skeleton could be as follows:

```nix
{
  description = "NixOS configuration with two or more channels";

  inputs = {
    nixpkgs.url = "nixpkgs/nixos-21.11"; 
    nixpkgs-unstable.url = "nixpkgs/nixos-unstable"; 
  };

  outputs = { self, nixpkgs, nixpkgs-unstable }:
    let
      system = "x86_64-linux";
      overlay-unstable = final: prev: {
        unstable = nixpkgs-unstable.legacyPackages.${prev.system};
        # use this variant if unfree packages are needed:
        # unstable = import nixpkgs-unstable {
        #   inherit system;
        #   config.allowUnfree = true;
        # };

      };
    in {
      nixosConfigurations."<hostname>" = nixpkgs.lib.nixosSystem {
        inherit system;
        modules = [
          # Overlays-module makes "pkgs.unstable" available in configuration.nix
          ({ config, pkgs, ... }: { nixpkgs.overlays = [ overlay-unstable ]; })
          ./configuration.nix
        ];
      };
    };
}

# NixOS configuration.nix, can now use "pkgs.package" or "pkgs.unstable.package"
{ config, pkgs, ... }: {
  environment.systemPackages = [pkgs.firefox pkgs.unstable.chromium];
  # ...
}
```

Same can be done with the NURs, as it already has an _overlay_ attribute in the flake.nix of the project, you can just add
```nix
nixpkgs.overlays = [ nur.overlay ];
```

If the variable `nixpkgs` points to the flake, you can also define `pkgs` with overlays with:
```nix
pkgs = import nixpkgs { overlays = [ /*the overlay in question*/ ]; };
```

#### Getting _Instant_ System Flakes Repl

How to get a nix repl out of your system flake:
```nix
# nix repl 
>> :lf /etc/nixos
```

Or out of your current flake:
```nix
# nix repl 
>> :lf .#
```
  
However, this won't be instant upon evaluation if any file changes have been done since your last configuration rebuild. Instead, if one puts:
```nix
nix.nixPath = let path = toString ./.; in [ "repl=${path}/repl.nix" "nixpkgs=${inputs.nixpkgs}" ];
```

In their system `flake.nix` configuration file, and includes the following file in their root directory flake as `repl.nix`:
```nix
let
  flake = builtins.getFlake (toString ./.);
  nixpkgs = import <nixpkgs> { };
in
{ inherit flake; }
// flake
// builtins
// nixpkgs
// nixpkgs.lib
// flake.nixosConfigurations
```
(Don't forget to `git add repl.nix && nixos-rebuild switch --flake "/etc/nixos"`) Then one can run (or bind a shell alias):
```shell
source /etc/set-environment && nix repl $(echo $NIX_PATH | perl -pe 's|.*(/nix/store/.*-source/repl.nix).*|\1|')
```
This will launch a repl with access to `nixpkgs`, `lib`, and the `flake` options in a split of a second.

###### Enable unfree software

Because flake evalutations are hermetic, they will ignore the system configuration on nonfree software and the `NIXPKGS_ALLOW_UNFREE` environment variable by default.

To use nonfree software with CLI tools like `nix shell` or `nix run`, the `--impure` flag must be used for Nixpkgs to access the current environment variables:
```shell
$ NIXPKGS_ALLOW_UNFREE=1 nix run --impure nixpkgs#discord
```

To use nonfree software in a flake, add `nixpkgs` as an input in your flake and import it with the `allowUnfree` option:
```shell
pkgs = import nixpkgs { config = { allowUnfree = true; }; }
```

##### Enable unfree software in home-manager

If you want to install software using home-manager via nix flakes in non NixOS systems (like darwin) you can use the home-manager `nixpkgs.config` option for example

```nix
nixpkgs.config.allowUnfree = true;
```

#### Official Nix links

These are links out to information from official Nix sources on Flakes.

-   [Eelco Dolstra's RFC #49](https://github.com/NixOS/rfcs/pull/49) - This is the initial RFC for Flakes to be included in NixOS, from July 2019
-   [spec describing flake inputs in more detail](https://github.com/NixOS/nix/blob/master/src/nix/flake.md)

#### See also

-   [Practical Nix Flakes](https://serokell.io/blog/practical-nix-flakes) - 2021: Intro article on working with Nix and Flakes
-   [flake-utils: Library to avoid some boiler-code when writing flakes](https://github.com/numtide/flake-utils)
-   [zimbat's direnv article](https://zimbatm.com/NixFlakes/#direnv-integration)
-   [Nix Flakes, Part 1: An introduction and tutorial](https://www.tweag.io/blog/2020-05-25-flakes/)
-   [Nix Flakes, Part 2: Evaluation caching](https://www.tweag.io/blog/2020-06-25-eval-cache/)
-   [Nix Flakes, Part 3: Managing NixOS systems](https://www.tweag.io/blog/2020-07-31-nixos-flakes/)
-   [Nix flakes 101: Introduction to nix flakes](https://www.youtube.com/watch?v=QXUlhnhuRX4&list=PLgknCdxP89RcGPTjngfNR9WmBgvD_xW0l)
-   [building Rust and Haskell flakes](https://github.com/nix-community/todomvc-nix)
---
### Previous Notes
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [Christine Doderill - Xe - Nix Flakes - An Introduction](https://christine.website/blog/nix-flakes-1-2022-02-21)
- [NixOS Wiki - Flakes](https://nixos.wiki/wiki/Flakes)
