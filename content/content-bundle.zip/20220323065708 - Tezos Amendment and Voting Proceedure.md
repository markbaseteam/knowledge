---
id: 202203We065708
title: 20220323065708 - Tezos Amendment and Voting Proceedure
creation date: 2022-03-23 06:57
modification date: Wednesday 23rd March 2022 06:57:08
note type:  Permanent Note
tags: blockchain tezos amendment voting proceedure hangzhou
---

# 20220323065708 - Tezos Amendment and Voting Proceedure
---
## Note



---
### Previous Notes
- [20220323064729 - Tezos Protocol Structure](20220323064729%20-%20Tezos%20Protocol%20Structure.md)
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
