---
id: 202202Mo142548
title: 20220228142548 - Nix Flakes - Packages and How to Use Them
creation date: 2022-02-28 14:25
modification date: Monday 28th February 2022 14:25:48
note type:  Literature Note
tags: development nix flakes packages
---

# 20220228142548 - Nix Flakes - Packages and How to Use Them
---
## Note

### What is a Package?
In Nix, you build packages by creating derivations that define the build steps and associated inputs (such as the compiler) to end up with the resulting outputs (derivation being the product of deriving something). Consider a package like this:

```nix
# hello-shell.nix
with import <nixpkgs> { };
stdenv.mkDerivation {
  name = "hello-HEAD";
  src = ./.;
  installPhase = ''
    echo "Hello" > $out
  '';
}
```

Then we can build this package with nix-build hello-shell.nix and a result symlink will show up in your current working directory. Then you can view what it says with cat:

```shell
$ cat ./result
Hello
```

This is all it takes to make a Nix package. You need to name the package, give it input source code somehow, and potentially give it build instructions

---
### Previous Notes
- [20220228125610 - Nix Flakes - An Introduction](../PermanentNote/20220228125610%20-%20Nix%20Flakes%20-%20An%20Introduction.md)


---
### Forward Notes
- [20220228154021 - Flake Registries](20220228154021%20-%20Flake%20Registries.md)

---
### External Links
- [Nix Flakes: Packages and How to Use Them](https://christine.website/blog/nix-flakes-2-2022-02-27)
- [Building with Flakes for reasons](https://blog.ysndr.de/posts/internals/2021-01-01-flake-ification/)