---
id: 202204Tu210312
title: 20220419210311 - Words relating to fetching or carrying things or people
creation date: 2022-04-19 21:03
modification date: Tuesday 19th April 2022 21:03:12
note type:  Permanent Note
tags: language french fetch carry
---

# 20220419210311
---
## Note





![Amener-emmener-apporter--emporter](../Artefacts/pictures/amener-emmener-apporter-emporter.png)


![Amener-emmener-apporter--emporter-2](../Artefacts/pictures/amener-emmener-apporter-emporter-2.png)


![ammener-emmener](../Artefacts/pictures/emmener-amener.png)


---
### Previous Notes
- [20220419195546 - Words involving Some or Any](20220419195546%20-%20Words%20involving%20Some%20or%20Any.md)
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
