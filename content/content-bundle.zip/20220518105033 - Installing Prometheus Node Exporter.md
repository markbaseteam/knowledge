---
id: 202205We105033
title: 20220518105033 - Installing Prometheus Node Exporter
creation date: 2022-05-18 10:50
modification date: Wednesday 18th May 2022 10:50:33
note type:  Permanent Note
tags: development prometheus devops
---

# 20220518105033 - Installing Prometheus Node Exporter
---
## Note

### Add Group
```bash
groupadd --system prometheus
```

### Add User

```bash
useradd -s /sbin/nologin --system -g prometheus prometheus
```

### Download Latest Release

```bash
 curl -s https://api.github.com/repos/prometheus/node_exporter/releases/latest | grep browser_download_url | grep linux-amd64 | cut -d '"' -f 4 | wget -qi -

```

### Unpack and move

```bash
tar -xvf node_exporter*.tar.gz
cd  node_exporter*/
sudo cp node_exporter /usr/local/bin
node_exporter --version
```

### Add Service

```bash
vim /etc/systemd/system/node_exporter.service
```

```bash
[Unit]
Description=Node Exporter
Wants=network-online.target
After=network-online.target
[Service]
User=prometheus
ExecStart=/usr/local/bin/node_exporter
[Install]
WantedBy=default.target
```

```bash
sudo systemctl daemon-reload
```
### Start and Enable Service
```bash
sudo systemctl start node_exporter
sudo systemctl enable node_exporter
systemctl status node_exporter.service
```


---
### Previous Notes
- [20220227194257 - Development](20220227194257%20-%20Development.md):
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
