---
id: 202204Tu122339
title: 20220419122339 - Tezos core operators for error monad
creation date: 2022-04-19 12:23
modification date: Tuesday 19th April 2022 12:23:39
note type:  Permanent Note
tags: blockchain tezos error monad operators
---

# 20220419122339 - Tezos core operators for error monad
---
## Note
The error monad in Tezos comes with a number of custom 'monadic' type operators.  These operators are so common in the code-base that one needs to understand them.  Additionally, there is a push to superseed them with let style bindings that add a further layer of opaqueness to the codebase.    All the operators listed make heavy use of the [Lwt lib](https://github.com/ocsigen/lwt) and objects


### Operators (defined using Lwt)
#### Bind / flatMap  => F[A] -> (A -> F[B]) -> F[B]
```ocaml
val ( >>= ) : 'a Lwt.t -> ('a -> 'b Lwt.t) -> 'b Lwt.t
```
 The equivalent let binding is: 
```ocaml
val ( let* ) : 'a Lwt.t -> ('a -> 'b Lwt.t) -> 'b Lwt.t
```
there is also and additional let operator specific to the Lwt-only expressions:
```ocaml
`val ( let*! ) : 'a Lwt.t -> ('a -> 'b Lwt.t) -> 'b Lwt.t`
```
(*yes! the reasoning for this is confusing as hell* )

#### Monadic Map   =>   F[A] -> (A -> B) -> F[B]
```ocaml
val ( >|= ) : 'a Lwt.t -> ('a -> 'b) -> 'b Lwt.t
```
Let equivalent: 
```ocaml
val ( let+ ) : 'a Lwt.t -> ('a -> 'b) -> 'b Lwt.t
```

#### Zip operators => F[A] -> F[B] -> F[A * B]
There are two operators for the zip operation (or combine) which arguably give consistent readability depending if you are in a monadic or applicative context (see [20220419132200 - Ocaml operator rationale](20220419132200%20-%20Ocaml%20operator%20rationale.md)), even though there is no structural difference.  

##### Monadic context
```ocaml
`val ( and* ) : 'a Lwt.t -> 'b Lwt.t -> ('a * 'b) Lwt.t`
```

##### Applicative context
```ocaml
`val ( and+ ) : 'a Lwt.t -> 'b Lwt.t -> ('a * 'b) Lwt.t`
```


### Usage of ! and ? in operators

#### ? operator
> The `?` operator in bindings like `let*?` represents the uncertainty involved in the `result` type. Is it a success or is it a failure?

#### ! operator
> The `!` operator in bindings like `let*!` represents the impossibility of errors. Thou shall not fail`!`.


## Result  operators
We ignore the 'trace type here for clarity

#### Bind / flatMap  => Result[A] -> (A -> Result[B]) -> Result[B] 
```ocaml
val ( >>? ) :  ('a, 'trace) result -> ('a -> ('b, 'trace) result) -> ('b, 'trace) result
```
This has a specific let operator for the Result type
```ocaml
val ( let* ) : ('a, 'e) result -> ('a -> ('b, 'e) result) -> ('b, 'e) result
```

#### Monadic map  => Result[A] -> (A -> B) -> Result[B]
```ocaml
val ( >|? ) : ('a, 'trace) result -> ('a -> 'b) -> ('b, 'trace) result
```
This has a specific operator for the Result type

```ocaml
val ( let+ ) : ('a, 'e) result -> ('a -> 'b) -> ('b, 'e) result
```

####  Embedded bind => F[Result[A]] -> (A -> F[Result[B]]) -> F[Result[B]] 
```ocaml
val ( >>=? ) :  ('a, 'trace) result Lwt.t ->  ('a -> ('b, 'trace) result Lwt.t) ->  ('b, 'trace) result Lwt.t
```

#### Embedded map => F[Result[A]] -> (A -> B) -> F[Result[B]]
```ocaml
val ( >|=? ) :  ('a, 'trace) result Lwt.t -> ('a -> 'b) -> ('b, 'trace) result Lwt.t
```

#### => Result[A] -> (A -> F[Result[B]]) -> F[Result[B]]
```ocaml
val ( >>?= ) :  ('a, 'trace) result ->  ('a -> ('b, 'trace) result Lwt.t) ->  ('b, 'trace) result Lwt.t
```

#### Traverse => Result[A] -> (A -> G[B]) -> G[Result[B]]
```ocaml
val ( >|?= ) :  ('a, 'trace) result -> ('a -> 'b Lwt.t) -> ('b, 'trace) result Lwt.t
```

## Option operators

#### Embedded bind / flatMap => Option[A] -> (A -> F[Option[B]]) -> F[Option[B]]]
```ocaml
val ( let*? ) : 'a option -> ('a -> 'b option Lwt.t) -> 'b option Lwt.t
```


## Operator Guidelines
If you are feeling overwhelmed by the different syntax modules, here are some simple guidelines.

- If your function returns `(_, _) result Lwt.t` values, then you start the function with `let open Lwt_result_syntax in`. Within the function you use:
	- `let` for vanilla expressions,
	- `let*` for `Lwt-result` expressions,
	- `let*!` for `Lwt-only` expressions,
	- `let*?` for `result-only` expressions.

And you end your function with a call to `return`.

- If your function returns `(_, _) result` values, then you start the function with `let open Result_syntax in`. Within the function you use:
	- `let` for vanilla expressions,
	- `let*`` for result expressions,

And you end your function with a call to `return`.

- If your function returns `_ Lwt.t` values, then you start the function with `let open Lwt_syntax in`.
	- `let` for vanilla expressions,
	- `let*` for Lwt expressions,

And you end your function with a call to `return`.

These are rules of thumb and there are exceptions to them. Still, they should cover most of your uses and, as such, they are a good starting point.


## Legacy Comparison

### Legacy code


(This section will be removed once the whole code-base has been updated to use the binding operators as recommended. In the meantime, you need to learn some legacy constructs so you can read code that hasn’t been upgraded yet. You should not use the operators introduced in this section to write new code.)

The legacy code is written with infix bindings instead of `let`-style binding operators. The binding `>>?` for `result` and `tzresult`, `>>=` for Lwt, and `>>=?` for Lwt-`result` and Lwt-`tzresult`. A full equivalence table follows.

![Tezos Legacy Comparison Part 1](../Artefacts/pictures/Tezos-legacy-comparison-part-1.png)

![Tezos Legacy Comparison Part 2](../Artefacts/pictures/Tezos-legacy-comparison-part-2.png)

In addition, instead of dedicated `return` and `fail` functions from a given syntax module, the legacy code relied on global values.

![Tezos Legacy Comparison Part 3](../Artefacts/pictures/Tezos-legacy-comparison-part-3.png)


Matching against a trace:

```ocaml
match f () with
| Ok .. -> ..
| Error (Timeout :: _) -> ..
| Error trace -> ..
```
This is discouraged because the compiler is unable to warn you if the matching is affected by a change in the code. E.g., if you add context to an error in one place in the code, you may change the result of the matching somewhere else in the code.





---
### Previous Notes
- [20220419094308 - Tenderbake](20220419094308%20-%20Tenderbake.md)
- [20220419132200 - Ocaml operator rationale](20220419132200%20-%20Ocaml%20operator%20rationale.md)

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [Legacy Code](https://tezos.gitlab.io/developer/error_monad_p4_appendices.html#legacy-code)
- [EX02]:
