---
id: 202204Tu195546
title: 20220419195546 - Words involving Some or Any
creation date: 2022-04-19 19:55
modification date: Tuesday 19th April 2022 19:55:46
note type:  Permanent Note
tags: language french something somewhere sometimes someone anything anywhere anytime anyone
---

# 20220419195546 - Words involving Some or Any
---
## Note
| | Some | Any |
| --- | --- | --- |
| Thing | Quelque chose | N'importe quoi |
| Where | Quelque part | N'importe où |
| Time(s) | Quelquefois | N'importe quand |
| One | Quelqu'un | N'importe qui | 

---
### Previous Notes
- [20220227190329 - French](20220227190329%20-%20French.md)
- [BW02]:

---
### Forward Notes
- [20220419210311 - Words relating to fetching or carrying things or people](20220419210311%20-%20Words%20relating%20to%20fetching%20or%20carrying%20things%20or%20people.md)
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
