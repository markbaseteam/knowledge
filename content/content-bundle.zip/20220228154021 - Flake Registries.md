---
id: 202202Mo154021
title: 20220228154021 - Flake Registries
creation date: 2022-02-28 15:40
modification date: Monday 28th February 2022 15:40:21
note type:  Permanent Note
tags: development nix flakes registries
---

# 20220228154021 - Flake Registries
---
## Note
Quick detour into registries! Registries are a way to alias popular flakes using identifiers:
```shell
# list a few predefined registries
$ nix registry list
. . . 
global flake:nixpkgs github:NixOS/nixpkgs
global flake:patchelf github:NixOS/patchelf
global flake:nix-serve github:edolstra/nix-serve
global flake:templates github:NixOS/templates
global flake:nickel github:tweag/nickel
. . .

# you can do 
$ nix flake show nickel

# instead of 
$ nix flake show github:tweag/nickel

# which is short for
$ nix flake show git+https://github.com/tweag/nickel
```

You might notice a registry called templates aliased to github:NixOS/templates. Take a peek with nix flake show:
```shell
$ nix flake show templates
github:NixOS/templates/79f48a7b822f35c068c5e235da2e9fbd154cecee
├───defaultTemplate: template: A very basic flake
└───templates
    ├───bash-hello: template: An over-engineered Hello World in bash
    ├───c-hello: template: An over-engineered Hello World in C
    ├───rust-web-server: template: A Rust web server including a NixOS module
    ├───simpleContainer: template: A NixOS container running apache-httpd
    └───trivial: template: A very basic flake
```
Aha! There is a flake output called defaultTemplate. This is the template being sourced when you run nix flake init. Astute readers may conclude the following:
```shell
$ nix flake init

# is equivalent to
$ nix flake init -t templates#defaultTemplate

# is equivalent to
$ nix flake init -t github:NixOS/templates#defaultTemplate

# which is short for
$ nix flake init -t git+https://github.com/NixOS/templates#defaultTemplate
```

Similarly, the other templates can be accessed via:
```shell
$ nix flake init -t templates#c-hello
$ nix flake init -t templates#simpleContainer
# I think you get the drift ...
```


---
### Previous Notes
- [20220228125610 - Nix Flakes - An Introduction](../PermanentNote/20220228125610%20-%20Nix%20Flakes%20-%20An%20Introduction.md)
- [20220228142548 - Nix Flakes - Packages and How to Use Them](../PermanentNote/20220228142548%20-%20Nix%20Flakes%20-%20Packages%20and%20How%20to%20Use%20Them.md)

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [Novice Nix: Flake Templates](https://peppe.rs/posts/novice_nix:_flake_templates/)

