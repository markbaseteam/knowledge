---
id: 202209Th110404
title: 20220929110404 - Cosmovisor Setup
creation date: 2022-09-29 11:04
modification date: Thursday 29th September 2022 11:04:04
note type:  Permanent Note
tags:  blockchain cosmos quicksilver
---

# 20220929110404 - Cosmovisor Setup
---
## Note

```bash
go install github.com/cosmos/cosmos-sdk/cosmovisor/cmd/cosmovisor@v1.3.0
mkdir -p ~/.quicksilverd/cosmovisor
mkdir -p ~/.quicksilverd/cosmovisor/genesis
mkdir -p ~/.quicksilverd/cosmovisor/genesis/bin
mkdir -p ~/.quicksilverd/cosmovisor/upgrades

echo "# Setup Cosmovisor" >> ~/.profile
echo "export DAEMON_NAME=quicksilverd" >> ~/.profile
echo "export DAEMON_HOME=$HOME/.quicksilverd" >> ~/.profile
echo "export DAEMON_ALLOW_DOWNLOAD_BINARIES=false" >> ~/.profile
echo "export DAEMON_LOG_BUFFER_SIZE=512" >> ~/.profile
echo "export DAEMON_RESTART_AFTER_UPGRADE=true" >> ~/.profile
echo "export UNSAFE_SKIP_BACKUP=true" >> ~/.profile
source ~/.profile

systemctl stop quicksilverd 

cp $GOPATH/bin/quicksilverd ~/.quicksilverd/cosmovisor/genesis/bin

sudo tee /etc/systemd/system/quicksilverd.service > /dev/null <<EOF
[Unit]
Description=quicksilver Daemon
After=network-online.target

[Service]
User=$USER
ExecStart=$(which cosmovisor) start
Restart=always
RestartSec=3
LimitNOFILE=infinity
LimitNPROC=infinity

Environment="DAEMON_HOME=$HOME/.quicksilverd"
Environment="DAEMON_NAME=quicksilverd"
Environment="DAEMON_ALLOW_DOWNLOAD_BINARIES=false"
Environment="DAEMON_RESTART_AFTER_UPGRADE=true"
Environment="DAEMON_LOG_BUFFER_SIZE=512"
Environment="UNSAFE_SKIP_BACKUP=true"

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable quicksilverd
sudo systemctl restart quicksilverd && sudo journalctl -u quicksilverd -f
```

---
### Previous Notes
- [20220827082234 - Quicksilver Node Setup](20220827082234%20-%20Quicksilver%20Node%20Setup.md):
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
