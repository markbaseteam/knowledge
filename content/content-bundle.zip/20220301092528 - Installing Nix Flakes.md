---
id: 202203Tu092528
title: 20220301092528 - Installing Nix Flakes
creation date: 2022-03-01 09:25
modification date: Tuesday 1st March 2022 09:25:28
note type:  Permanent Note
tags: development nix flakes install
---

# 20220301092528 -  Installing Nix Flakes
---
## Note

Flakes are only available in nix unstable and have to be enabled explicitly.

##### NixOS

In NixOS this can be achieved with the following options in `configuration.nix`.

###### System-wide installation

```nix
{ pkgs, ... }: {
  nix = {
    package = pkgs.nixUnstable; # or versioned attributes like nix_2_4
    extraOptions = ''
 experimental-features = nix-command flakes
 '';
   };
}
```

###### Installation as an extra command

Add command `nixFlakes` that serves as a flakes-enabled alias to the `nix` command.

```nix
{ pkgs, ... }: {
  environment.systemPackages = [
    (pkgs.writeShellScriptBin "nixFlakes" ''
 exec ${pkgs.nixFlakes}/bin/nix --experimental-features "nix-command flakes" "$@"
 '')
  ];
}
```

##### Non-NixOS

On non-nixos systems, install `nixFlakes` in your environment:
```bash
$ nix-env -iA nixpkgs.nixFlakes
```

Edit either ```~/.config/nix/nix.conf``` or ```/etc/nix/nix.conf``` and add:

```nix
experimental-features = nix-command flakes
```

This is needed to expose the Nix 2.0 CLI and flakes support that are hidden behind feature-flags.

Finally, if the Nix installation is in multi-user mode, don’t forget to restart the nix-daemon.

There is no official installer yet, but you can use the [nix-unstable-installer][1]



---
### Previous Notes
- [20220228083802 - Nix](20220228083802%20-%20Nix.md)
- [20220301095742 - Reasons to use Nix Flakes](20220301095742%20-%20Reasons%20to%20use%20Nix%20Flakes.md)

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [1]: https://github.com/numtide/nix-unstable-installer#systems "Unstable Installer"
