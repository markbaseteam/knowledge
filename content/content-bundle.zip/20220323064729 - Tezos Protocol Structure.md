---
id: 202203We064729
title: 20220323064729 - Tezos Protocol Structure
creation date: 2022-03-23 06:47
modification date: Wednesday 23rd March 2022 06:47:29
note type:  Permanent Note
tags: blockchain tezos protocol structure octopus
---

# 20220323064729 - Tezos Protocol Structure
---
## Note
The characteristic that makes Tezos unique is its self-amending property. The part that amends itself is called [20220323065144 - Tezos Economic Protocol](20220323065144%20-%20Tezos%20Economic%20Protocol.md) (the green eye of the octopus), sometimes abbreviated by protocol or even proto in the source code. The rest of a Tezos node is what we call the _shell_ (the blue octopus).

![Octopus](../Artefacts/pictures/octopus.svg)


The protocol is responsible for interpreting the transactions and other administrative operations. It also has the responsibility to detect erroneous blocks.
e
An important thing to notice is that the protocol always sees only one block chain, that is a linear sequence of blocks since the genesis. It does not know that it lives in an open network where nodes can propose alternative heads.

Only the shell knows about the multiple heads. It is responsible for choosing between the various chain proposals that come from the bakers (the programs that cook new blocks) of the network. The shell has the responsibility of selecting and downloading alternative chains, feed them to the protocol, which in turn has the responsibility to check them for errors, and give them an absolute score. The shell then simply selects the valid head of the highest absolute score. This part of the shell is called [20220323065344 - Tezos Validator](20220323065344%20-%20Tezos%20Validator.md).

The rest of the shell includes the peer-to-peer layer, the disk storage of blocks, the operations to allow the node to transmit the chain data to new nodes and the versioned state of the ledger. In-between the validator, the peer-to-peer layer, and the storage sits a component called the distributed database, that abstracts the fetching and replication of new chain data to the validator.

Protocols are compiled using a tweaked Ocaml compiler (green part on the left of the picture) that does two things. First, it checks that the protocol’s main module has the right type. A good analogy is to see protocol as plug-ins, and in this case, it means that it respects the common plugin interface. Then, it restricts the typing environment of the protocol’s code so that it only calls authorised modules and functions. Seeing protocols as plug-ins, it means that the code only called primitives from the plug-in API. It is a form of statically enforced sand boxing.

Note that the economic protocol on the chain is subject to an amendment procedure. On-chain operations can be used to switch from one protocol to another. The procedure is described in more details in [20220323065708 - Tezos Amendment and Voting Proceedure](20220323065708%20-%20Tezos%20Amendment%20and%20Voting%20Proceedure.md)

Finally, the RPC layer (in yellow on the right in the picture) is an important part of the node. It is how the client, third-party applications and daemons can interact with the node and introspect its state. This component uses the mainstream JSON format and HTTP protocol. It uses the library `resto`. It is fully interoperable, and auto descriptive, using JSON schema.






---
### Previous Notes
- [20220228100634 - Tezos](20220228100634%20-%20Tezos.md)

---
### Forward Notes
- [20220323065144 - Tezos Economic Protocol](20220323065144%20-%20Tezos%20Economic%20Protocol.md)
- [20220323080251 - Working with the Tezos protocol](20220323080251%20-%20Working%20with%20the%20Tezos%20protocol.md)

---
### External Links
- [The Big Picture](https://tezos.gitlab.io/shell/the_big_picture.html)
- [EX02]:
