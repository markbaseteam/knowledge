---
id: 202203We100042
title: 20220302100042 - Nix Flakes output schema
creation date: 2022-03-02 10:00
modification date: Wednesday 2nd March 2022 10:00:42
note type:  Permanent Note
tags: development nix flakes output schema
---

# 20220302100042- Nix Flakes output schema
---
## Note



---
### Previous Notes
- [20220301092528 - Installing Nix Flakes](20220301092528%20-%20Installing%20Nix%20Flakes.md)
- [20220301095742 - Reasons to use Nix Flakes](20220301095742%20-%20Reasons%20to%20use%20Nix%20Flakes.md)
- [20220302094620 - Nix Flakes import schema](20220302094620%20-%20Nix%20Flakes%20import%20schema.md)

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [EX01]:
- [EX02]:
