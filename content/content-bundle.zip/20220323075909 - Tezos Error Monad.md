---
id: 202203We075909
title: 20220323075909 - Tezos Error Monad
creation date: 2022-03-23 07:59
modification date: Wednesday 23rd March 2022 07:59:09
note type:  Permanent Note
tags:
---

# 20220323075909 - Tezos Error Monad
---
## Note

## The Error Monad
There are multiple ways to deal with errors in OCaml: exceptions, `result`, `option`, etc., each approach has strengths and weaknesses. However, in Octez we settle on one, single, uniform way of dealing with errors: the _error monad_.

This is a tutorial for the error monad. It makes the following assumptions

-   You can read English.
    
-   You have a basic familiarity with OCaml.
    
-   You have a basic familiarity with Lwt (if not, this tutorial links to Lwt resources when it becomes necessary).
    

Other than that, each section of this tutorial can be understood using the information of previous sections, no additional information is necessary. Note, however, that most sections also make forward references along the lines of “more details on this later” or “alternatives are presented later”. During a first read, this foreshadowing is only useful in that it lets you know that the information is coming and that you can move on with a partial understanding. On subsequent reads, it helps putting things in context.

Note that the core of this tutorial focuses on error management in Octez. For a short section on error management in the protocol see Part 3 [Working within the protocol](https://tezos.gitlab.io/developer/error_monad_p3_advanced.html#error-monad-within-protocol).

-   [Part 1: `result`, Lwt, and Lwt-`result`](https://tezos.gitlab.io/developer/error_monad_p1_result.html)
    -   [The `result` type](https://tezos.gitlab.io/developer/error_monad_p1_result.html#the-result-type)
    -   [The binding operator](https://tezos.gitlab.io/developer/error_monad_p1_result.html#the-binding-operator)
    -   [Aside: the `Error_monad` module is opened everywhere](https://tezos.gitlab.io/developer/error_monad_p1_result.html#aside-the-error-monad-module-is-opened-everywhere)
    -   [Recovering from errors](https://tezos.gitlab.io/developer/error_monad_p1_result.html#recovering-from-errors)
    -   [Mixing different kinds of errors](https://tezos.gitlab.io/developer/error_monad_p1_result.html#mixing-different-kinds-of-errors)
    -   [The `Result_syntax` module](https://tezos.gitlab.io/developer/error_monad_p1_result.html#the-result-syntax-module)
    -   [Lwt](https://tezos.gitlab.io/developer/error_monad_p1_result.html#lwt)
    -   [The `Lwt_syntax` module](https://tezos.gitlab.io/developer/error_monad_p1_result.html#the-lwt-syntax-module)
    -   [Promises of results: Lwt and `result` together](https://tezos.gitlab.io/developer/error_monad_p1_result.html#promises-of-results-lwt-and-result-together)
    -   [The `Lwt_result_syntax` module](https://tezos.gitlab.io/developer/error_monad_p1_result.html#the-lwt-result-syntax-module)
    -   [Converting errors of promises](https://tezos.gitlab.io/developer/error_monad_p1_result.html#converting-errors-of-promises)
    -   [Lifting](https://tezos.gitlab.io/developer/error_monad_p1_result.html#lifting)
    -   [Wait! There is too much! What module am I supposed to open locally and what operators should I use?](https://tezos.gitlab.io/developer/error_monad_p1_result.html#wait-there-is-too-much-what-module-am-i-supposed-to-open-locally-and-what-operators-should-i-use)
    -   [What’s an error?](https://tezos.gitlab.io/developer/error_monad_p1_result.html#whats-an-error)
    -   [Wait! It was supposed to be “one single uniform way of dealing with errors”! What is this?](https://tezos.gitlab.io/developer/error_monad_p1_result.html#wait-it-was-supposed-to-be-one-single-uniform-way-of-dealing-with-errors-what-is-this)
    -   [META COMMENTARY](https://tezos.gitlab.io/developer/error_monad_p1_result.html#meta-commentary)
---
### Previous Notes
- [20220323070526 - Tezos Software Architecture and Packages Relationship](20220323070526%20-%20Tezos%20Software%20Architecture%20and%20Packages%20Relationship.md)
- [BW02]:

---
### Forward Notes
- [FW01]:
- [FW02]:

---
### External Links
- [Tezos Error Monad Tutorial](https://tezos.gitlab.io/developer/error_monad.html):
- [EX02]:
