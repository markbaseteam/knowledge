---
id: 202203We094620
title: 20220302094620 - Nix Flakes import schema
creation date: 2022-03-02 09:46
modification date: Wednesday 2nd March 2022 09:46:20
note type:  Permanent Note
tags: development nix flakes import schema
---

# 20220302094620- Nix Flakes import schema
---
## Note

Nix flakes defines pure imports.  The schema is as follows:

```nix
inputs.<inputname> = {
  url = git+<url-to-git-repo>[?ref=****[&rev=****]]
      | (github|gitlab):<user>/<repo>[/<ref> | ?ref=****[&rev=****]];
      | <known-flake>[/<ref> | ?ref=****[&rev=****]]
      | /absolute/path
  flake = true | false; # default = true
}
```

### Input URL

use `git+<url>` to checkout a git repository at `<url>`
use `/local/absolute/path` to load a local source
use `gitlab:<user>/<repo>/github:<user>/<repo>` to shortcut gitlab or github repositories
use `<known-flake>` to shortcut to a globally defined alias

### Known Flake
`known-flake` - nix will manage a registry of named flakes that can be included as is and are a shortcut to another repo by default following global registry items are defined in the [flake-registry repo][1] and available in every nix installation:

```nix
global flake:blender-bin github:edolstra/nix-warez
global flake:dwarffs github:edolstra/dwarffs
global flake:hydra github:NixOS/hydra
global flake:nimble github:nix-community/flake-nimble
global flake:nix github:NixOS/nix
global flake:nixops github:NixOS/nixops
global flake:nixos-hardware github:NixOS/nixos-hardware
global flake:nixos-homepage github:NixOS/nixos-homepage/flake
global flake:nur github:nix-community/NUR
global flake:nixpkgs/release-19.09 github:edolstra/nixpkgs/release-19.09
global flake:nixpkgs github:NixOS/nixpkgs
global flake:templates github:NixOS/templates
global flake:patchelf github:NixOS/patchelf
```

If using a `<known-flake>` nix will not use your respective channel even if one with the same name such as `nixpkgs` exists.

### Specifying a commit or branch

By default, the main branch of the repository pointed to will be used as to provide the dependency flake.
Nix will also update dependencies to the latest commit on `nix flake update` calls
to pin repositories to a certain commit or override the default branch append a `?ref=commit-ref` or `?<branch>` respectively.

### Non flake inputs

Nix will try to interpret inputs as flakes, to suppress that, set `<inputname>.flake = false`.

### Overriding dependency inputs

Traditionally, if one wanted a dependency to use a certain nixpkgs version (i.e. to make use of binary caches) one would specify a certain `nixpkgs` argument while importing. Flakes allow the same thing by setting `inputs.<inputname>.inputs.<inputname>.follows = <local inputsname>`.


---
### Previous Notes
- [20220301095742 - Reasons to use Nix Flakes](20220301095742%20-%20Reasons%20to%20use%20Nix%20Flakes.md)
- [20220301092528 - Installing Nix Flakes](20220301092528%20-%20Installing%20Nix%20Flakes.md)

---
### Forward Notes
- [20220302100042 - Nix Flakes output schema](20220302100042%20-%20Nix%20Flakes%20output%20schema.md)
- [FW02]:

---
### External Links
- [1]: https://github.com/NixOS/flake-registry 
- [EX02]:
